package proyectoaula.ventanas;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Formatter;
import java.util.Properties;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class VentanaElectrodomestico extends javax.swing.JFrame {
    String elec = File.separator;
    String crearblock = System.getProperty("user.dir")+elec+"DatosTXT"+elec;
    
    public VentanaElectrodomestico() {
        initComponents();
    }
    private void crear(){
    String archivo = nroserie.getText()+".txt";
    File crearubi = new File(crearblock);
    File creararchivo = new File(crearblock + archivo);
    
    if(nroserie.getText().equals("")){
        JOptionPane.showMessageDialog(rootPane, "este electrodomestico no existe");
    
    }else{
        try{
            if(creararchivo.exists()){
            JOptionPane.showMessageDialog(rootPane, "este electrodomestico ya esta registrado");
            }else{
            crearubi.mkdirs();
            Formatter crearFor = new Formatter(crearblock + creararchivo);
            crearFor.format("%s/r/n %s\r\n %s\r\n","Electrodomestico" + electrodomestico.getText(),"Nro. Serie"+nroserie.getText(),"Marca"+marca.getText());
            crearFor.close();
            JOptionPane.showMessageDialog(rootPane, "el electrodomestico a sido guardado");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(rootPane, "no se a podido ingresar el electrodomestico");
             
        }
    
    }
    
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelElectrodomestico = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        RegresarVentana = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        marca = new javax.swing.JTextField();
        electrodomestico = new javax.swing.JTextField();
        nroserie = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        Guardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        PanelElectrodomestico.setBackground(new java.awt.Color(204, 204, 255));
        PanelElectrodomestico.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(205, 255, 205));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        RegresarVentana.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        RegresarVentana.setText("Regresar");
        RegresarVentana.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarVentanaActionPerformed(evt);
            }
        });
        jPanel1.add(RegresarVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 330, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Electrodomestico", "Nro. Serie", "Marca"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 120, 318, 165));

        jLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel1.setText("Nro. Serie:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, -1, -1));

        jLabel2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel2.setText("Electrodomestico:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setText("Marca:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, -1, -1));

        marca.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jPanel1.add(marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 210, 190, -1));

        electrodomestico.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jPanel1.add(electrodomestico, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, 190, -1));

        nroserie.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jPanel1.add(nroserie, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 190, -1));

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 36)); // NOI18N
        jLabel4.setText("ingrese electrodomesticos");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 100));

        Guardar.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        Guardar.setText("guardar");
        Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarActionPerformed(evt);
            }
        });
        jPanel1.add(Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 250, -1, -1));

        PanelElectrodomestico.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 480));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelElectrodomestico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PanelElectrodomestico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegresarVentanaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarVentanaActionPerformed
        Ventana abc = new Ventana();
        abc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegresarVentanaActionPerformed

    private void GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarActionPerformed
        crear();
        
        electrodomestico.setText("");
        nroserie.setText("");
        marca.setText("");
    }//GEN-LAST:event_GuardarActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable(){
            public void run() {
                new VentanaElectrodomestico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Guardar;
    private javax.swing.JPanel PanelElectrodomestico;
    private javax.swing.JButton RegresarVentana;
    private javax.swing.JTextField electrodomestico;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField marca;
    private javax.swing.JTextField nroserie;
    // End of variables declaration//GEN-END:variables
}
